/**
 * 
 */
/**
 * 
 */
module college {
}